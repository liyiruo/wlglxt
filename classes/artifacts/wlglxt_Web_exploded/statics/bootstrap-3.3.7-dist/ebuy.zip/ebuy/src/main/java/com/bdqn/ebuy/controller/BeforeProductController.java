package com.bdqn.ebuy.controller;

import com.bdqn.ebuy.pojo.Product;
import com.bdqn.ebuy.service.product.ProductService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by hp on 2017/12/19.
 */
@Controller
@RequestMapping("/product")
public class BeforeProductController {
    @Resource
    private ProductService productService;

    @RequestMapping("/listByType")
    public String listByType(Product product, Model model){
        List<Product> products = productService.findProductByTypeID(product);
        model.addAttribute("products", products);
        return "before/productList";
    }

    @RequestMapping("/findByID")
    public String findByID(Integer id){
        Product product = productService.findProductByID(id);
        return "before/product";
    }
}
