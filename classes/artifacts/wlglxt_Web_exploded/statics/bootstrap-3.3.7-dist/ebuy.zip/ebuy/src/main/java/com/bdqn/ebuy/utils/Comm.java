package com.bdqn.ebuy.utils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by hp on 2017/12/18.
 */
public class Comm {
    public final static String CUR_USER = "cur_user";
    public static Map<String, String> success(){
        Map<String, String> message = new HashMap<String,String>();
        message.put("code", "0000");
        message.put("message","操作成功");
        return message;
    }
    public static Map<String, String> failed(){
        Map<String, String> message = new HashMap<String,String>();
        message.put("code", "0001");
        message.put("message","操作失败");
        return message;
    }
}
