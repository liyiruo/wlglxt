package com.bdqn.ebuy.dao.product;

import com.bdqn.ebuy.pojo.Product;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by hp on 2017/12/19.
 */
public interface ProductMapper {
    List<Product> findProductByTypeID(@Param("product") Product product);
    Product findProductByID(Integer id);

    List<Product> queryProductBycategoryLevel1Id(Integer categoryLevel1Id);

}
