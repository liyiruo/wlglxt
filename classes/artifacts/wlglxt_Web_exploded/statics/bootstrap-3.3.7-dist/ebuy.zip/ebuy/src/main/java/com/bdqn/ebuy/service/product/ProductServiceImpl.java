package com.bdqn.ebuy.service.product;

import com.bdqn.ebuy.dao.product.ProductMapper;
import com.bdqn.ebuy.pojo.Product;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by hp on 2017/12/19.
 */
@Service
public class ProductServiceImpl implements ProductService {
    @Resource
    private ProductMapper productMapper;

    @Override
    public List<Product> findProductByTypeID(Product product) {
        return productMapper.findProductByTypeID(product);
    }

    @Override
    public Product findProductByID(Integer id) {
        return productMapper.findProductByID(id);
    }

    @Override
    public List<Product> queryProductBycategoryLevel1Id(Integer categoryLevel1Id) {
        return productMapper.queryProductBycategoryLevel1Id(categoryLevel1Id);
    }

}
