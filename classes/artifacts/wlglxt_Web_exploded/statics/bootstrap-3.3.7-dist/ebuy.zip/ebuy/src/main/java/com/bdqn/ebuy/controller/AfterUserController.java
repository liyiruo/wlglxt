package com.bdqn.ebuy.controller;

import com.alibaba.fastjson.JSON;
import com.bdqn.ebuy.pojo.User;
import com.bdqn.ebuy.service.user.UserService;
import com.bdqn.ebuy.utils.Comm;
import com.bdqn.ebuy.utils.MD5;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

/**
 * Created by hp on 2017/12/18.
 */
@Controller
@RequestMapping("/afterUser")
public class AfterUserController {
    @Resource
    private UserService userService;

    @RequestMapping("/login")
    public String login(String loginName, String password, HttpSession session){
        User user_login = new User();
        user_login.setLoginName(loginName);
        String password1 = null;
        try {
            password1 = MD5.getMD5(password);
        } catch (Exception e) {
            e.printStackTrace();
        }
        user_login.setPassword(password1);
        User user_login1 = userService.login(user_login);
        if(user_login1!=null){
            session.setAttribute(Comm.CUR_USER,user_login1);
            return "after/after_index";
        }
        return "after/login";
    }

    @RequestMapping(value = "/findUserByID",
            produces = {"application/json;charset=UTF-8"})
    @ResponseBody
    public String findUserByID(Integer id){
        User userTemp = userService.detailUser(id);
        return JSON.toJSONString(userTemp);
    }

    @RequestMapping(value = "/delUser",
            produces = {"application/json;charset=UTF-8"})
    @ResponseBody
    public String delUser(Integer id){
        int result = userService.deleteUserById(id);
        if(result>0){
            return JSON.toJSONString(Comm.success());
        }
        return JSON.toJSONString(Comm.failed());
    }

    @RequestMapping(value = "/updateUser", method = RequestMethod.POST,
            produces = {"application/json;charset=UTF-8"})
    @ResponseBody
    public String updateUser(User user){
        int result = userService.updateUser(user);
        if(result>0){
            return JSON.toJSONString(Comm.success());
        }
        return JSON.toJSONString(Comm.failed());
    }
}
