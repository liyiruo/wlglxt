package com.bdqn.ebuy.service.product;

import com.bdqn.ebuy.pojo.Product;

import java.util.List;

/**
 * Created by hp on 2017/12/19.
 */
public interface ProductService {
    List<Product> findProductByTypeID(Product product);
    Product findProductByID(Integer id);
    List<Product> queryProductBycategoryLevel1Id(Integer categoryLevel1Id);
}
